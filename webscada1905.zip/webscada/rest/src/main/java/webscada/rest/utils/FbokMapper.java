package webscada.rest.utils;

import lombok.Getter;
import lombok.Setter;
import webscada.entity.User;

@Setter
@Getter
public class FbokMapper extends User {
	private String first_name;
}
