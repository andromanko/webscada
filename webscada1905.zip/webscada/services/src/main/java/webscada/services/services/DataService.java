package webscada.services.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import webscada.api.dao.IValueJPADao;
import webscada.api.dto.DevDto;
import webscada.api.dto.DevTypeDto;
import webscada.api.dto.ValueReal;
import webscada.api.mappers.DevMapper;
import webscada.api.mappers.UserMapper;
import webscada.api.services.IDataService;
import webscada.api.services.IDevService;
import webscada.api.services.IEventService;
import webscada.api.services.IUserService;
import webscada.api.utils.IModbusTCP;
import webscada.entity.User;
import webscada.entity.Value;

@Slf4j
@Service
public class DataService implements IDataService {

	private static Map<Long, ValueReal> dataMap = new HashMap<>();

	private static List<ValueReal> data = new ArrayList<>();

	private volatile boolean started = false;

	@Autowired
	private IValueJPADao valueJPADao;

	@Autowired
	private IDevService devService;

	@Autowired
	private IModbusTCP modbusTCP;

	@Autowired
	private IEventService eventService;
	@Autowired
	private IUserService userService;

	@Override
	public Map<Long, ValueReal> getAllData() {

		for (ValueReal valueReal : data) {
			dataMap.put(valueReal.getId(), valueReal);
		}
		return dataMap;
	}

	@Override
	public List<ValueReal> readAllData(Principal principal) {
		List<DevDto> devices = devService.getDevs();
		// data.clear();
		// List<ValueReal> data = new ArrayList<>();
		// TODO сделать через stream map collect
		// source.stream().map(DevMapper::mapDev).collect(Collectors.toList());
		for (DevDto device : devices) {
			List<Value> values = valueJPADao.findByDevId(DevMapper.mapDev(device));
			if (!values.isEmpty()) {
				data.addAll(readDevData(device, values));
			}
		}
		analizeData(principal);
		return data;
	}

	private List<ValueReal> readDevData(DevDto devDto, List<Value> values) {

		DevTypeDto devType = devDto.getDevType();
		List<ValueReal> vals = new ArrayList<>();

		switch (devType.getId()) {
		case 1:
			vals.addAll(modbusTCP.start(DevMapper.mapDev(devDto), values));
			return vals;
		case 2:
			// TODO FX5U next version
			return null;
		case 3:
			// TODO next version readWebData( devDto, values);
			ValueReal value = ValueReal.builder().id((long) 3).name("testDevTypeId=3").units("testUnits").number(13.3)
					.build();
			vals.add(value);
			return vals;
		default:
			log.info("dev type not defined" + devType);
			return null;
		}
	}

	@Override
	public boolean writeData(ValueReal valueReal, DevDto devDtoo) {
		// TODO Auto-generated method stub
		return false;
	}

	private void analizeData(Principal principal) {
		List<Value> values = valueJPADao.findAll();
		for (Value value : values) {
			long id = value.getId();
			ValueReal valueReal = dataMap.get(id);
			if (valueReal != null) {

				double max = (double) value.getMax();

				double min = (double) value.getMin();

				double number = (double) ((int) valueReal.getNumber());
				
				if (number > max && !valueReal.isHigh()) {
					// TODO add time
					//User user = UserMapper.mapUser(userService.findUserByLogin("Roma"));
					
					User user = (User)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
					eventService.createEvent(1, user, value.getDevId());
					valueReal.setHigh(true);
					// TODO emailSender...
				} else if (number < max) {
					valueReal.setHigh(false);
				}

				if (number < min & !valueReal.isLow()) {
					// TODO add time
					//User user = UserMapper.mapUser(userService.findUserByLogin("Roma"));
					eventService.createEvent(2, null, value.getDevId());
					valueReal.setLow(true);
					// TODO emailSender...
				}else if (number > min) {
					valueReal.setLow(false);
				}
			}
		}
	}
}
