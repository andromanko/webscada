# webscada
My first java project =)

This project will connection with several remote devices (industrial automation, HVAC, PLC, remoteI/O etc...) and make visualisation on web-page.
Simple! Cheap! And flexiblity!

For the first time it will work only with MODBUS TCP protocol.
