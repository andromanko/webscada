package webscada.utils.communication;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

import webscada.api.dto.ValueReal;
import webscada.api.services.IDataService;
import webscada.api.utils.IModbusTCP;

public class ScheduledTask {
	@Autowired
	private IDataService dataService;

	@Scheduled(fixedDelay = 180000, initialDelay = 1000)
	public void scheduleFixedRateWithInitialDelayTask() {
		
		List<ValueReal> data = dataService.readAllData();
		    
		long now = System.currentTimeMillis() / 1000;
	   	    
	    System.out.println(
	      "Fixed rate task with one second initial delay - " + now);
	}
	
}
