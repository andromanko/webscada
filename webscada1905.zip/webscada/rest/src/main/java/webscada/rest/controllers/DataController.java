package webscada.rest.controllers;

import java.security.Principal;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import webscada.api.dto.EventDto;
import webscada.api.dto.EventStringDto;
import webscada.api.dto.UserDto;
import webscada.api.mappers.UserMapper;
import webscada.api.services.IDataService;
import webscada.api.services.IDevService;
import webscada.api.services.IEventService;
import webscada.entity.Event;
import webscada.entity.User;
import webscada.entity.Value;
import webscada.api.dto.ValueReal;

@RestController
@RequestMapping("/monitor")
public class DataController {

	@Autowired
	private IDevService devService;

	@Autowired
	private IDataService dataService;

	@Autowired
	private IEventService eventService;


	@GetMapping("/s")
	@Scheduled(fixedDelay = 30000, initialDelay = 30000)
	public void viewDataSch() {
		//TODO principal here! 
		dataService.readAllData(null);
		
	}

	@GetMapping
	public ModelAndView viewData() {

		Map <Long, ValueReal> data = dataService.getAllData();
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("monitor");
		modelAndView.addObject("title", "Data");
		modelAndView.addObject("dataList", data);
		return modelAndView;
	}

	@GetMapping(value = "/events")
	public ModelAndView viewEvents() {

		List<EventStringDto> data = eventService.getEventsString();
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("eventsPage");
		// modelAndView.addObject("title", "Data");
		modelAndView.addObject("eventList", data);
		return modelAndView;
	}


}
