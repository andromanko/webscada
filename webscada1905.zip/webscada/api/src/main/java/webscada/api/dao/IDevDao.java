package webscada.api.dao;

import webscada.entity.Dev;

public interface IDevDao extends IAGenericDao<Dev> {

}
