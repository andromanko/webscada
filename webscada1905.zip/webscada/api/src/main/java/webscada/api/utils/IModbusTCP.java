package webscada.api.utils;

import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import webscada.api.dto.ValueReal;
import webscada.entity.Dev;
import webscada.entity.Value;

import java.util.List;
import java.util.Map;

@Service
public interface IModbusTCP {
	public List<ValueReal> start(Dev dev, List<Value> values);
	public void stop();
	
}
