package webscada.api.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import lombok.experimental.UtilityClass;
import webscada.api.dto.DevTypeDto;
import webscada.api.dto.UserDto;
import webscada.entity.DevType;
import webscada.entity.User;

@UtilityClass
public class DevTypeMapper {

	// DevTypeMapper INSTANCE = Mappers.getMapper( DevTypeMapper.class );

	// DevType mapDevType(DevTypeDto source);

	// DevTypeDto mapDevTypeDto(DevType source);
	public DevTypeDto mapDevTypeDto(DevType source) {
		DevTypeDto retval = DevTypeDto.builder()
                .id(source.getId())
                .type(source.getType())
                .description(source.getDescription())
                .url(source.getUrl())
                .build();
		return retval;
	}
	public DevType mapDevType(DevTypeDto source) {
		DevType retval = DevType.builder()
                .id(source.getId())
                .type(source.getType())
                .description(source.getDescription())
                .url(source.getUrl())
                .build();
		return retval;
	}
}
