package webscada.api.dao;

import webscada.entity.User;

public interface IUserDao extends IAGenericDao<User> {

}
