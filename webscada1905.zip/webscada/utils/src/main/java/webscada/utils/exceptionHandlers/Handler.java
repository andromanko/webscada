package webscada.utils.exceptionHandlers;

public class Handler {

}
