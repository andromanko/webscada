package webscada.rest.config;

import java.util.Locale;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

import webscada.services.config.ServiceConfiguration;

@Configuration
@ComponentScan("webscada.rest")
@Import(value =  {ServiceConfiguration.class})
public class RestConfiguration {

		@Bean
		public LocaleResolver localResolver() {
			SessionLocaleResolver sessionLocaleResolver = new SessionLocaleResolver();
			sessionLocaleResolver.setDefaultLocale(Locale.US);
			return sessionLocaleResolver;
		}
		
		//TODO 28.04 2:10:03
		
		@Bean
		public LocaleChangeInterceptor localeChangeInterceptor() {
			LocaleChangeInterceptor localeChangeInterceptor = new LocaleChangeInterceptor();
			localeChangeInterceptor.setParamName("lang");
			return localeChangeInterceptor;
			
		}
}
